/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h> 
using namespace std;

void swap(int *a,int *b){
    int temp = *a;
    *a = *b;
    *b = temp;    
}

int partition(int arr[], int low, int high){
    int pivot = arr[high];
    int i = (low-1);
    for(int j=low; j<high; j++){
        if(arr[j]<pivot){
            i++;
            swap(&arr[i],&arr[j]);
        }       
    }
    swap(&arr[i+1],&arr[high]);
    return (i+1);
}

void quickSort(int arr[],int low,int high){
    if(low<high){
        int partIndex = partition(arr,low,high);
        quickSort(arr,low,partIndex-1);
        quickSort(arr,partIndex+1,high);
    }
    
}




int main()
{
    // vector<int> arr;
    int arr[100];
    int n,temp;
    cout<<"Enter the length of array\t";
    cin>>n;
    cout<<"Enter the elements of array\n";
    for(int i=0; i<n; i++){
        // cin>>temp;
        // arr.push_back(temp);
        cin>>arr[i];
    }
    quickSort(arr,0,n-1);
    cout<<"Sorted array\n";
    for(int i=0; i<n; i++)
        cout<<arr[i]<<"\t";
    return 0;
}
