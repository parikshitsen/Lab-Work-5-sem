/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream> 
using namespace std; 
int binarySearch(int a[], int start, int end, int x) 
{ 
	if (end >= start) { 
		int mid = start + (end - start) / 2; 
		if (a[mid] == x){
			return mid; 
		} 
		else if (a[mid] > x){
			return binarySearch(a, start, mid - 1, x); 
		} 
		else if(a[mid] < x){
		    return binarySearch(a, mid + 1, end, x); 
		}
	} 
	return -1; 
} 

int main(void) 
{ 
    int a[100],n;
    int find;
    cout<<"Enter length of array \t";
    cin>>n;
    cout<<"Enter elements of array\n";
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    cout<<"Enter the element to find\t";
    cin>>find;
	int result = binarySearch(a, 0, n - 1, find); 
	if(result == -1){
	    cout << "Not found";
	}
	else{
        cout << "Location of element is: " << result+1; 
	}
	return 0; 
} 
