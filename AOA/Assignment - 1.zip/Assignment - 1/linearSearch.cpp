/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<iostream>
using namespace std;

int search(int arr[], int n, int x) 
{ 
    int i; 
    for (i = 0; i < n; i++) 
        if (arr[i] == x) 
            return i; 
    return -1; 
}

int main()
{
    int arr[100],n,find;
    cout << "Enter the length of array:\t";
    cin >> n;
    cout << "Enter elements of array\n";
    for(int i=0; i<n; i++)
        cin >> arr[i];
    cout << "Enter the element to find\t";
    cin >> find;
    int result = search(arr,n,find);
    if(result==-1)
        cout << "Not found";
    else
        cout << "Location of element is: " << result+1;
    return 0;
}
